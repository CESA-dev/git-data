
import unittest
from models import *
from datetime import datetime

class TestModels(unittest.TestCase):
    """ """
    def setUp(self):
        """ """
        self.model = Post()
        self.model.dbInfo['db'] = 'test_project_default' 
        self.author_data = {
                'name' : 'test user',
                'email' : 'test@test.com',
                'contacts' : []
                }
        self.author = Author()
        self.author.dbInfo['db'] = 'test_project_default'
        self.author_id = self.author.create(self.author_data)
        self.dbdata = {
                'id' : self.author_id,
                'title' : 'testtitle',
                'createdAt' : datetime.now(),
                'modifiedAt' : datetime.now(),
                'author' : self.author_id,
                'body' : '123',
                'resources' : ['http://www.baidu.com', 'http://www.google.com/a.jpg'],
                'tags' : ['6w6', '7w7'],
                }

        self.data = {
                'id' : '233',
                'title' : 'testtitle',
                'createdAt' : None,
                'modifiedAt' : None,
                'author' : None,
                'body' : None,
                'resources' : None,
                'tags' : None,
                }
    
    def tearDown(self):
        """ """
        
        data = {'author': self.author_id}
        self.model.delete(data)
        data = {'id' : self.author_id}
        self.author.delete(data)

    def test_data_null(self):
        """ """
        with self.assertRaises(ValueError):
            print(self.model.toJSON(self.data))

    def test_data_error(self):
        """ """
        self.data['createdAt'] = datetime.now()
        self.data['modifiedAt'] = datetime.now()
        self.data['author'] = None
        self.data['body'] = 'hello world!'
        self.data['resources'] = ['http://www.baidu.com', 'http://www.google.com/a.jpg']
        self.data['tags'] = ['6w6', '7w7']
        
        with self.assertRaises(ValueError):
            self.model.validateData(data=self.data)


    def test_data_correct(self):
        """ """
        self.data['createdAt'] = datetime.now()
        self.data['modifiedAt'] = datetime.now()
        self.data['author'] = self.author_id
        self.data['body'] = 'hello world!'
        self.data['resources'] = ['http://www.baidu.com', 'http://www.google.com/a.jpg']
        self.data['tags'] = ['6w6', '7w7']
        
        self.assertTrue(self.model.validateData(data=self.data))

    def test_create_doc_null(self):
        """ """
        with self.assertRaises(ValueError):
            retval = self.model.create(self.data)

    def test_create_doc_full(self):
        """ """
        retval = self.model.create(self.dbdata) 

    def test_read_doc_full(self):
        """ """
        retval = self.model.create(self.dbdata)
        result = self.model.read({'id' : retval})
        self.assertEqual(len(result), 1)

    def test_update_doc_full(self):
        """ """
        retval = self.model.create(self.dbdata)
        result = self.model.read({'id' : retval})
        r = result[0]
        uid = str(r['id'])
        retval = self.model.update({'id' : uid, 'title' : 'brand new title'})
        result = self.model.read({'id' : str(retval['id'])})
        r = result[0]
        self.assertEqual(r['title'], 'brand new title')

    def test_delete_full(self):
        """ """
        retval = self.model.create(self.dbdata)
        result = self.model.read({'id' : retval})
        r = result[0]
        uid = str(r['id'])
        retval = self.model.delete({'id' : uid})
        self.assertEqual(retval, 1)


if __name__ == '__main__':
    unittest.main()

