from flask_restful import Resource
import urllib2
import re
import json
import redis
from resources.config import REDIS_HOST
class EWSStatus(Resource):
    def get(self):
        key = 'app.stats.ewsstatus.count'
        r = redis.StrictRedis(host=REDIS_HOST, port=6379, db=0)
        r.incr(key)
        response = urllib2.urlopen("https://my.engr.illinois.edu/labtrack/util_data_json.asp")
        return json.load(response)
