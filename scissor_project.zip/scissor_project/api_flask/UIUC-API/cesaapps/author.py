
from flask import request
from flask_restful import Resource
import json
from backbone.models import Author
from cesaapps.config import MONGODB_HOST
from cesaapps.auth import AuthenticatedResource
class CreateAuthor(AuthenticatedResource):
    """Routing for creating author
    Example Request::   
    
        {
          "name" : "test",
          "email" : "pop@qq.com",
          "contacts" : [],
          "session_id": "ANK5HEIIQLJ3P7YMZD8GD6LS4DHVESM6FTD3DC0S01ITMFY3L52JU003DVSCZ2C54P4XI494P0UN5I030587OQH0ZC3KJ88XPN6SG877ZY2I2J6RFEPFJRBMNK695QPH"
        }

    Example Respond::
 
        {
            "id": "58fdc4a2d9528a0009c3a5f1"
        }

    """
    def authenticated_post(self):
        """ """
        json_data = self.json_request
        model = Author()
        model.setdbInfo(host=MONGODB_HOST)
        try:
            retval = model.create(json_data)
        except ValueError as e:
            return e.message
        return {'id': str(retval)} 

class SearchAuthor(Resource):
    """ """

    def post(self):
        """ """
        json_data = request.get_json(force=True)
        model = Author()
        model.setdbInfo(host=MONGODB_HOST)
        try:
            retval = model.read(json_data)
        except ValueError as e:
            return e.message
        return retval

class UpdateAuthor(AuthenticatedResource):
    """ """

    def authenticated_post(self):
        """ """
        json_data = self.json_request
        model = Author()
        model.setdbInfo(host=MONGODB_HOST)
        try:
            retval = model.update(json_data)
        except ValueError as e:
            return e.message
        return retval

class DeleteAuthor(AuthenticatedResource):
    """ """

    def authenticated_post(self):
        """ """
        json_data = self.json_request
        model = Author()
        model.setdbInfo(host=MONGODB_HOST)
        try:
            retval = model.delete(json_data)
        except ValueError as e:
            return e.message
        return {'deleteCount': str(retval)} 






