"""
A module for authentication routes

.. moduleauthor:: Xiangbin Hu <hu.xgbn@gmail.com>

"""


from functools import wraps
from flask import abort, request
from flask_restful import Resource
from backbone.models import User
import json
import bcrypt
from cesaapps.config import MONGODB_HOST



AUTH_STRIP_LIST = ['session_id']




class Login(Resource):
    """Routing for user Register
    Example Request::   
    
        {
          "username" : "wtf",
          "password" : "1234qwer"
        }

    Example Respond::
 
        {
        "session_id": "ANK5HEIIQLJ3P7YMZD8GD6LS4DHVESM6FTD3DC0S01ITMFY3L52JU003DVSCZ2C54P4XI494P0UN5I030587OQH0ZC3KJ88XPN6SG877ZY2I2J6RFEPFJRBMNK695QPH"
        }

    """
    def post(self):
        """"""
        json_data = request.get_json(force=True)
        if 'username' in json_data and 'password' in json_data:
            username = json_data['username']
            password = json_data['password']
        else:
            abort(401)
        model = User()
        model.setdbInfo(host=MONGODB_HOST)
        login = {'username' : username, 'password' : password}
        retval = model.login(login)
        if retval is not None:
            return {'session_id' : retval}

        abort(401)


class Register(Resource):
    """Routing for user Register
    Example Request::   
    
        {
            "email" : "wtf@qq.com",
            "name" : "wtf",
            "password" : "1234qwer"
        }

    Example Respond::

        "58fdc31cd9528a0009c3a5ed"

    """
    def post(self):
        """ """
        json_data = request.get_json(force=True)
        model = User()
        model.setdbInfo(host=MONGODB_HOST)
        try:
            retval = model.register(json_data)
        except ValueError as e:
            return e.message
        return retval


class AuthenticatedResource(Resource):
    """Routing for user Authentication, all protected route should inherit this class"""
    def post(self):
        """ """
        self.json_request = request.get_json(force=True)
        if 'session_id' not in self.json_request:
            abort(401)
        session_id = self.json_request['session_id']
        model = User()
        model.setdbInfo(host=MONGODB_HOST)
        if not model.authenticate(session_id):
            abort(401)
        return self.authenticated_post()

    def authenticated_post(self):
        """ """
        abort(404)

    







