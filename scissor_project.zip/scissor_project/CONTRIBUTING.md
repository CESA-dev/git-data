
# Branches

We are following the guideline here: <br/>
https://docs.gitlab.com/ce/workflow/gitlab_flow.html#github-flow-as-a-simpler-alternative

__master__ <br/>
This branch is dedicated to development.

__production__ <br/>
This branch is dedicated to production.

# Issue branch

For every issue, go to the issue page and click _Create Branch_ button. This
will create a branch for that issue. When the issue is solved, you can create a 
merge request.



