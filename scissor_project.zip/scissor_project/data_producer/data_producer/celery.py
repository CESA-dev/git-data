from __future__ import absolute_import

from celery import Celery
from celery.utils.log import get_task_logger
from data_producer import celeryconfig
from data_producer.data_producer_config import CELERY_BACKEND_REDIS_HOST, CELERY_BROKER_REDIS_HOST

i_get_task_logger = get_task_logger

app = Celery('data_producer',
        broker='redis://{}:6379'.format(CELERY_BROKER_REDIS_HOST),
        backend='redis://{}:6379'.format(CELERY_BACKEND_REDIS_HOST), 
        include=['data_producer.laundry', 'data_producer.crawl_dining'])
app.config_from_object(celeryconfig)


if __name__ == '__main__':
    app.start()


