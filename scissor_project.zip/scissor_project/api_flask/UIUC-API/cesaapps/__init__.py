"""
A module for cesaapps
"""


