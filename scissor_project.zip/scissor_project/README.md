#Scissor Project
## Introduction
This is a backend project developed by Chinese Engineering Student Assocation (CESA) . 

## Using this service
This section includes a detailed step-by-step explaination about how to use this service

### To Run the Service

1. download docker 
<br/>[docker for mac](https://docs.docker.com/engine/getstarted/step_one/#docker-for-mac)
<br/>[docker for windows](https://docs.docker.com/engine/getstarted/step_one/#docker-for-windows)
<br/>[docker for linux](https://docs.docker.com/engine/getstarted/step_one/#docker-for-linux)
2. use the following command line scripts to initialize the local git content after you cloned this project:
```
cd scissor_project
git submodule init && git submodule update
```
<br/><br/>
__Explaination__: This repo includes an external repo: [UIUC-API](https://wut2eat.com:9092/CESA/UIUC-API), which is extended from the original repo from github to fit the needs of CESA. Therefore, we need the submodule commands from git to keep the external repo updated.

3. use the following commands to build the docker images. This is gonna take a while because it downloads the base images from the offical docker registry and applies a bunch of modifications specified by the DockerFiles in the project.
```
cd scissor_project
make
```
4. use the following commands to start the server
```
cd scissor_project
make deploy
```
<br/><br/>
__Explaination__: step 3 and step 4 both include a _make_ command. The _make_ commands are defined in Makefile. You should study [A good docker tutorial I found online](https://prakhar.me/docker-curriculum/) to understand what they do.

5. After the steps above, you should be able to see 4 docker containers up and running using `docker ps`

![alt text](./assets/docker_screenshot.png "docker screenshot")
_A screen shot of what it is supposed to look like now_

### To Stop the Service
1. Use `make stop` to stop all containers and delete all containers
2. Use `make purge` to clean all downloaded images

## Directories

__api_flask__:
<br/>
A directory containing the UIUC-API submodule and related DockerFile
<br/>

__data_producer__:
<br/>
The directory containing the data producer code and related DockerFile
<br/>

__redis__:
<br/>
The directory containing the redis DockerFile
<br/>

__mongo__:
<br/>
A directory reserved for mongodb data
<br/>

## Available APIs

All following interfaces assumes that you already know the host and port. If you want to test the service running on your own machine, it is http://localhost:5000 by default.

### CESA CRUD interfaces
#### Posts
+ /cesaapps/post/create
+ /cesaapps/post/search
+ /cesaapps/post/delete
+ /cesaapps/post/update

#### Authors
+ /cesaapps/author/create
+ /cesaapps/author/search
+ /cesaapps/author/delete
+ /cesaapps/author/update

### UIUC interfaces
#### Dining
+ /dining/HallName/mm_dd_yyyy'
<br/>
_Example_: /dining/Ikenberry/04_06_2017


#### laundry
+ /laundry
+ /laundry/RoomName
<br/>
 