"""
A module that contains the implementations of all models

NOTICE:
    attributes need to be initialized to be included in __dict__
    plural attributes should be list, e.g. resources, tags.
"""

from __future__ import print_function
from abc import ABCMeta, abstractmethod
import json
from pymongo import MongoClient
from validators import DefaultValidator, UserRegisterValidator
from bson import ObjectId
from datetime import datetime
from ..config import MONGODB_HOST, REDIS_HOST
import copy
import bcrypt
import redis
import string
import random
'''
NOTICE:
    attributes need to be initialized to be included in __dict__
    plural attributes should be list, e.g. resources, tags.
'''

STRIP_KEYS = ['session_id']

class Base:
    """
    The base abstract class for all models
    """
    __metaclass__ = ABCMeta

    def __init__(self):
        self.client = None
        self.schema = None # schema used by the validator
        self.updateSchema = None # schema used for update
        self.validator = None # the validator
        self.updateValidator = None # the update validator
        self.dbInfo = {
                'host' : 'localhost', 
                'port' : 27017,
                'db' : 'project_default',
                'collection' : 'wow'} 
        # a dict where the first is the url and the second is port

    def setdbInfo(self, **kwargs):
        """method to set database info for this model

        :param **kwargs: keyward arguments for setdbInfo 

        *Available keyword arguments*

        * host: host in string, such as 127.0.0.1
        * port: port in number
        * db:   the name of the db
        * collection: the name of the collection

        *Default configuration*::

            {
                'host' : 'localhost', 
                'port' : 27017,
                'db' : 'project_default',
                'collection' : 'wow'
            }
        
        """
        for key in ('host', 'port', 'db', 'collection'):
            if key in kwargs:
                self.dbInfo[key] = kwargs[key]


    def validateData(self, data=None):
        """

        :param data:  (Default value = None)

        """
        if self.validator is None:
            raise ValueError('validator is not set')
        if self.schema is None:
            raise ValueError('schema is not set')
        if data is None:
            raise ValueError('data is not set')

        if not self.validator.validate(data):
            raise ValueError(self.validator.errors)
        return True

    def validateUpdateData(self, data=None):
        """

        :param data:  (Default value = None)

        """
        if self.updateValidator is None:
            raise ValueError('validator is not set')
        if self.updateSchema is None:
            raise ValueError('schema is not set')
        if data is None:
            raise ValueError('data is not set')

        if not self.updateValidator.validate(data):
            raise ValueError(self.updateValidator.errors)
        return True


    def toJSON(self, data):
        """returns json string representing the model

        :param data: the data to be translated to json 

        """
        if self.validateData(data=data):
            return json.dumps(data)
        
        # should never get here
        return None
    
    def _get_db_client(self):
        """ """
        self.client = MongoClient(self.dbInfo['host'], self.dbInfo['port'])
        return self.client

    def _get_db_db(self):
        """ """
        client = self._get_db_client()
        return client[self.dbInfo['db']]

    def _get_db_collection(self):
        """ """
        db = self._get_db_db()
        return db[self.dbInfo['collection']]
    
    def _strip_key_from_data(self, data):
        """

        :param data: 

        """
        for key in STRIP_KEYS:
            if key in data:
                del data[key]

    def create(self, data):
        """
        
        :param data: the json data to be inserted into the database 

        """
        self._strip_key_from_data(data)
        collection = self._get_db_collection()
        self.validateData(data)
        if 'id' in data:
            del data['id']
        if 'createdAt' in data:
            del data['createdAt']
        if 'modifiedAt' in data:
            del data['modifiedAt']
        d = datetime.now()
        data['modifiedAt'] = d
        data['createdAt'] = d

        uid = collection.insert_one(data).inserted_id
        self.client.close()
        return str(uid)

    def read(self, data):
        """

        :param data: the json data used for the search 

        """
        self._strip_key_from_data(data)
        collection = self._get_db_collection()
        if 'id' in data:
            uid = data['id']
            uid = ObjectId(uid)
            retval = collection.find({'_id' : uid})
        else:
            retval = collection.find(data) 
        self.client.close()
        ret = []
        for v in retval:
            v['id'] = str(v['_id'])
            del v['_id']
            v['createdAt'] = v['createdAt'].isoformat()
            v['modifiedAt'] = v['modifiedAt'].isoformat()
            ret.append(v)
        return ret 
        
        


    def update(self, data):
        """

        :param data: the json data used for update 

        """
        self._strip_key_from_data(data)
        collection = self._get_db_collection()
        if 'id' not in data:
            return -1
        uid = data['id']
        del data['id']
        if 'createdAt' in data:
            del data['createdAt']
        if 'modifiedAt' in data:
            del data['modifiedAt']
        data['modifiedAt'] = datetime.now()
        self.validateUpdateData(data)
        retval = collection.find_one_and_update({'_id' : ObjectId(uid)}, {'$set' : data})
        self.client.close()
        
        retval['id'] = str(retval['_id'])
        del retval['_id']
        retval['createdAt'] = retval['createdAt'].isoformat()
        retval['modifiedAt'] = retval['modifiedAt'].isoformat()
        return retval
        

    def delete(self, data):
        """

        :param data: the json data used for delete 

        """
        self._strip_key_from_data(data)
        collection = self._get_db_collection()
        if 'id' in data:
            uid = data['id']
            del data['id']
            data['_id'] = uid
            count = collection.delete_one({'_id' : ObjectId(uid)}).deleted_count
            self.client.close()
            return count
        count = collection.delete_many(data).deleted_count
        self.client.close()
        return count

            

class Post(Base):

    def __init__(self):
        super(Post, self).__init__()
        self.schema = {
                'id' : {
                    'type' : 'string'
                    },
                'title' : {
                    'required' : True,
                    'type' : 'string',
                    'maxlength' : 128
                    },
                'createdAt' : {
                    'type' : 'datetime'
                    },
                'modifiedAt' : {
                    'type' : 'datetime'
                    },
                'author' : {
                    'required' : True,
                    'type' : 'string'
                    },
                'body' : {
                    'required' : True,
                    'type' : 'string',
                    },
                'resources' : {
                    'required' : True,
                    'type' : 'list',
                    'schema' : {
                        'type' : 'url'
                        }
                    },
                'tags' : {
                    'required' : True,
                    'type' : 'list',
                    'schema' : {
                        'type' : 'string'
                        }
                    }
                }
               
        self.updateSchema = copy.deepcopy(self.schema)
        for key in self.updateSchema.keys():
            if 'required' in self.updateSchema[key]:
                del self.updateSchema[key]['required']
        self.validator = DefaultValidator(self.schema)
        self.updateValidator = DefaultValidator(self.updateSchema)
        self.dbInfo['collection'] = 'Post'

    def _validate_author(self, data):
        """

        :param data: 

        """
        if not 'author' in data:
            return
        author = Author()
        author.setdbInfo(host=MONGODB_HOST)
        # author.dbInfo['db'] = self.dbInfo['db']
        retval = author.read({'id' : data['author']})
        if len(retval) <= 0:
            msg = json.loads('{}')
            msg['error'] = 'no such user'
            msg['user'] = data['author']
            raise ValueError(json.dumps(msg))

    def create(self, data):
        """

        :param data: json data used for create 

        """
        self._validate_author(data)
        return super(Post, self).create(data)

    def read(self, data):
        """

        :param data: json data used for read 

        """
        self._validate_author(data)
        return super(Post, self).read(data)

    def update(self, data):
        """

        :param data: json data used for update

        """
        self._validate_author(data)
        return super(Post, self).update(data)
    
    def delete(self,data):
        """

        :param data: json data used for delete 

        """
        self._validate_author(data)
        return super(Post, self).delete(data)


class Author(Base):
    """ """
    
    def __init__(self):
        super(Author, self).__init__()
        self.schema = {
                'id' : {
                    'type' : 'string'
                    },
                'name' : {
                    'required' : True,
                    'type' : 'username'
                    },
                'createdAt' : {
                    'type' : 'datetime'
                    },
                'modifiedAt' : {
                    'type' : 'datetime'
                    },
                'email' : {
                    'required' : True,
                    'type' : 'email'
                    },
                'contacts' : {
                    'required' : True,
                    'type' : 'list',
                    'schema' : {
                        'type' : 'string'
                        }
                    }
                }

               
        self.updateSchema = copy.deepcopy(self.schema)
        for key in self.updateSchema.keys():
            if 'required' in self.updateSchema[key]:
                del self.updateSchema[key]['required']
        self.validator = DefaultValidator(self.schema)
        self.updateValidator = DefaultValidator(self.updateSchema)
        self.dbInfo['collection'] = 'Author'

    


class User(Base):
    """A user model for authentication"""
   
    REDIS_KEY_ = "app.cesaapps.auth.session_id."


    def __init__(self):
        super(User, self).__init__()

        self.register_schema = {

                'name' : {
                    'required' : True,
                    'type' : 'username'
                    },
                'email' : {
                    'required' : True,
                    'type' : 'email'
                    },
                'password' : {
                    'required' : True,
                    'type' : 'password'
                    }

                }
       
        self.schema = {
                'id' : {
                    'type' : 'string'
                    },
                'name' : {
                    'required' : True,
                    'type' : 'username'
                    },
                'createdAt' : {
                    'type' : 'datetime'
                    },
                'modifiedAt' : {
                    'type' : 'datetime'
                    },
                'email' : {
                    'required' : True,
                    'type' : 'email'
                    },
                'password' : {
                    'required' : True,
                    'type' : 'string'
                    }

                }

               
        self.updateSchema = copy.deepcopy(self.schema)
        for key in self.updateSchema.keys():
            if 'required' in self.updateSchema[key]:
                del self.updateSchema[key]['required']
        self.validator = DefaultValidator(self.schema)
        self.updateValidator = DefaultValidator(self.updateSchema)
        self.dbInfo['collection'] = 'User'


    def login(self, login):
        """

        :param login: the username password json for login 

        """
        username = login['username']
        password = login['password']
        try:
            retval = self.read({'name' : username})
        except ValueError as e:
            return None
        if len(retval) == 0:
            return None

        result = retval[0]
        if bcrypt.checkpw(password, result['password']):
            return self._generate_session_id()
        return None

    def authenticate(self, session_id):
        """

        :param session_id: session id
        :type session_id: string

        """
        r = redis.StrictRedis(host=REDIS_HOST, port=6379, db=0)
        return r.exists(self.REDIS_KEY_ + session_id) 
        
    def _generate_session_id(self):
        """ """
        session_id = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(128))
        r = redis.StrictRedis(host=REDIS_HOST, port=6379, db=0)
        r.set(self.REDIS_KEY_ + session_id, 1, ex=60000)
        return session_id

    def register(self, data):
        """

        :param data: json data used for register 

        """
        register_validator = UserRegisterValidator(self.register_schema)
        if not register_validator.validate(data):
            raise ValueError(register_validator.errors)
        hashed_pw = bcrypt.hashpw(data['password'], bcrypt.gensalt(14))
        data['password'] = hashed_pw
        ret = self.create(data)
        if 'password' in ret:
            del ret['password']
        return ret







