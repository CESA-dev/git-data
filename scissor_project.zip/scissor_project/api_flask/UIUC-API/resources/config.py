
REDIS_HOST = 'some-redis'


