

CELERY_BROKER_REDIS_HOST = 'some-redis'
CELERY_BACKEND_REDIS_HOST = 'some-redis'

APP_REDIS_HOST = 'some-redis'

