
from cerberus import Validator

import re

EMAIL_REGEX = re.compile(r"^[_]*([a-z0-9]+(\.|_*)?)+@([a-z][a-z0-9-]+(\.|-*\.))+[a-z]{2,6}$")
URL_REGEX = re.compile(r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+")

USERNAME_REGEX = re.compile(r"^[a-zA-Z0-9_.-]+$")
PASSWORD_REGEX = re.compile(r"[A-Za-z0-9@#$%^&+=]{8,}")

class DefaultValidator(Validator):
    """ """
    
    def _validate_type_email(self, value):
        """

        :param value: 

        """

        if EMAIL_REGEX.match(value):
           return True 
    
    def _validate_type_url(self, value):
        """

        :param value: 

        """
        if URL_REGEX.match(value):
            return True

    def _validate_type_id(self, value):
        """

        :param value: 

        """
        
        if len(value) == 24:
            return True

    def _validate_type_username(self, value):
        """

        :param value: 

        """
        if USERNAME_REGEX.match(value):
            return True

class UserRegisterValidator(DefaultValidator):
    """ """
    
    def _validate_type_password(self, value):
        """

        :param value: 

        """
        if PASSWORD_REGEX.match(value):
            return True



